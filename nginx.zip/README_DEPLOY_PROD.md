# SocengLab - Production Deployment (Nginx static + docker compose)

## Layout
We assume your project root contains `frontend/` and `backend/` as in the original zip.
This pack provides production Dockerfiles, compose, and Nginx configs.

## Files
- Dockerfile.frontend
- Dockerfile.backend
- docker-compose.prod.yml
- deploy/nginx/frontend.conf           (for the *frontend container* nginx)
- deploy/nginx/host.soceng.tegalsec.org.conf   (for the *host* Nginx reverse proxy)
- backend/.env.example

## Quick steps (Ubuntu 22.04/24.04)

1) Put this pack into your project root on the VPS, i.e. `/opt/socenglab/` so paths look like:
   - /opt/socenglab/frontend/...
   - /opt/socenglab/backend/...
   - /opt/socenglab/Dockerfile.frontend
   - /opt/socenglab/Dockerfile.backend
   - /opt/socenglab/docker-compose.prod.yml
   - /opt/socenglab/deploy/nginx/frontend.conf

2) Create backend env:
   ```bash
   cp backend/.env.example backend/.env
   # edit JWT_SECRET etc.
   ```

3) Build & start:
   ```bash
   docker compose -f docker-compose.prod.yml up -d --build
   docker compose -f docker-compose.prod.yml ps
   ```

4) Host Nginx reverse proxy
   Save `deploy/nginx/host.soceng.tegalsec.org.conf` to `/etc/nginx/sites-available/soceng.tegalsec.org`:
   ```bash
   sudo mkdir -p /var/www/certbot
   sudo cp deploy/nginx/host.soceng.tegalsec.org.conf /etc/nginx/sites-available/soceng.tegalsec.org
   sudo ln -sf /etc/nginx/sites-available/soceng.tegalsec.org /etc/nginx/sites-enabled/soceng.tegalsec.org
   sudo nginx -t && sudo systemctl reload nginx
   ```

5) Issue TLS:
   ```bash
   sudo apt -y install certbot python3-certbot-nginx
   sudo certbot --nginx -d soceng.tegalsec.org --agree-tos -m van@tegalsec.org -n
   ```

6) Test:
   ```bash
   curl -I https://soceng.tegalsec.org
   curl -I https://soceng.tegalsec.org/api/docs
   curl https://soceng.tegalsec.org/healthz
   ```

## Notes
- Frontend container serves static on 127.0.0.1:8080; backend serves API on 127.0.0.1:8001.
- Host Nginx terminates TLS and proxies / and /api to respective containers.
- REACT_APP_BACKEND_URL is baked into the frontend image at build time from `docker-compose.prod.yml` args.
- For zero-downtime updates: `docker compose -f docker-compose.prod.yml pull && docker compose -f docker-compose.prod.yml up -d --build`
